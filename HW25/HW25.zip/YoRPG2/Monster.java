// DANIEL ZABARI
// pd 9
// HW24
// 2013-11-13
public class Monster extends Character{

    public Monster(){
	_hp=150;
	_defense=20;
	_strength=((int)((Math.random()*45))+20);
	_attack=1;
    }
   





}
